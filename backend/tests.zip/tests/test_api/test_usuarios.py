import pytest
import sqlite3
from flask import Flask
from werkzeug.security import check_password_hash

# importa o blueprint
from ...src.blueprints.routes.usuarios import usuario_db
from ...database import get_dbd


@pytest.fixture
def app(tmp_path):
    """
    Cria uma aplicação Flask isolada para rodar os testes
    com um banco de dados SQLite em memória (ou arquivo temporário).
    """
    app = Flask(__name__)
    app.config["TESTING"] = True
    app.register_blueprint(usuario_db, url_prefix="/usuarios")

    # inicializa um banco só para testes
    db_path = tmp_path / "test.db"
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    # cria tabela de usuarios
    conn.execute("""
        CREATE TABLE usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            senha_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'recepcao',
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

    # sobrescreve get_dbd para sempre conectar no db de teste
    def override_get_dbd():
        c = sqlite3.connect(db_path)
        c.row_factory = sqlite3.Row
        return c

    global get_dbd
    get_dbd = override_get_dbd

    return app


@pytest.fixture
def client(app):
    return app.test_client()


def test_criar_usuario(client):
    resp = client.post("/usuarios/", json={
        "username": "teste1",
        "senha": "123456",
        "role": "admin"
    })
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["status"] == "ok"


def test_listar_usuarios(client):
    # cria um usuario
    client.post("/usuarios/", json={
        "username": "teste2",
        "senha": "abc123",
        "role": "medico"
    })

    resp = client.get("/usuarios/")
    assert resp.status_code == 200
    data = resp.get_json()
    assert isinstance(data, list)
    assert any(u["username"] == "teste2" for u in data)


def test_detalhar_usuario(client):
    # cria um usuario
    client.post("/usuarios/", json={
        "username": "teste3",
        "senha": "xyz123",
        "role": "recepcao"
    })

    # pega o id do usuario
    resp = client.get("/usuarios/")
    uid = resp.get_json()[-1]["id"]

    # busca detalhe
    resp = client.get(f"/usuarios/{uid}")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["username"] == "teste3"


def test_atualizar_usuario(client):
    # cria usuario
    client.post("/usuarios/", json={
        "username": "teste4",
        "senha": "senha1",
        "role": "recepcao"
    })

    # pega id
    resp = client.get("/usuarios/")
    uid = resp.get_json()[-1]["id"]

    # atualiza
    resp = client.put(f"/usuarios/{uid}", json={
        "username": "teste4_editado",
        "senha": "novaSenha",
        "role": "admin"
    })
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "atualizado"

    # confere
    resp = client.get(f"/usuarios/{uid}")
    data = resp.get_json()
    assert data["username"] == "teste4_editado"
    assert data["role"] == "admin"


def test_login_usuario(client):
    # cria usuario
    client.post("/usuarios/", json={
        "username": "teste5",
        "senha": "segredo",
        "role": "medico"
    })

    # login correto
    resp = client.post("/usuarios/login", json={
        "username": "teste5",
        "senha": "segredo"
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "autenticado"
    assert data["role"] == "medico"

    # login incorreto
    resp = client.post("/usuarios/login", json={
        "username": "teste5",
        "senha": "errado"
    })
    assert resp.status_code == 401


def test_deletar_usuario(client):
    # cria usuario
    client.post("/usuarios/", json={
        "username": "teste6",
        "senha": "delete",
        "role": "recepcao"
    })

    # pega id
    resp = client.get("/usuarios/")
    uid = resp.get_json()[-1]["id"]

    # deleta
    resp = client.delete(f"/usuarios/{uid}")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "deletado"

    # tenta buscar de novo
    resp = client.get(f"/usuarios/{uid}")
    assert resp.status_code == 404
