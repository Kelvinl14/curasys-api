import requests
import uuid

BASE_URL = "http://127.0.0.1:5000/pacientes"
ids = []  # lista para armazenar IDs criados


def test_1_post_pacientes():
    pacientes = [
        {"nome": "Paciente A", "data_nascimento": "1995-10-02", "cpf": str(uuid.uuid4())[:9], "telefone": "(85) 9999-9999",
         "email": "affa@mail"},
        {"nome": "Paciente B", "data_nascimento": "1995-10-02", "cpf": str(uuid.uuid4())[:9], "telefone": "(85) 9999-9998",
         "email": "bffa@mail"},
        {"nome": "Paciente C", "data_nascimento": "1995-10-02", "cpf": str(uuid.uuid4())[:9], "telefone": "(85) 9999-9997",
         "email": "cffa@mail"},
    ]

    for paciente in pacientes:
        response = requests.post(BASE_URL, json=paciente)
        assert response.status_code == 201


def test_2_get_pacientes():
    response = requests.get(BASE_URL)
    assert response.status_code == 200

    data = response.json()
    assert isinstance(data, list)

    # salvar os 3 primeiros IDs criados
    for item in data[-3:]:
        ids.append(item["id"])

    assert len(ids) == 3


def test_3_put_paciente():
    paciente_id = ids[1]  # segundo registro
    update_data = {"nome": "Paciente B Atualizado", "data_nascimento": "1995-10-02", "cpf": str(uuid.uuid4())[:9], "telefone": "(85) 9999-9997", "email": "affa@mail"}

    response = requests.put(f"{BASE_URL}/{paciente_id}", json=update_data)
    assert response.status_code == 200


def test_4_delete_paciente():
    paciente_id = ids[2]  # terceiro registro
    response = requests.delete(f"{BASE_URL}/{paciente_id}")
    assert response.status_code == 200
