import requests

BASE_URL = "http://127.0.0.1:5000/consultas"
ids = []


def test_1_post_consultas():
    consultas = [
        {"id_paciente": 1, "id_medico": 1, "data_consulta": "2025-09-10T12:00"},
        {"id_paciente": 2, "id_medico": 2, "data_consulta": "2025-09-11T14:00"},
        {"id_paciente": 3, "id_medico": 3, "data_consulta": "2025-09-12T08:00"},
    ]

    for consulta in consultas:
        response = requests.post(BASE_URL, json=consulta)
        assert response.status_code == 201


def test_2_get_consultas():
    response = requests.get(BASE_URL)
    assert response.status_code == 200

    data = response.json()
    assert isinstance(data, list)

    for item in data[-3:]:
        ids.append(item["id"])

    assert len(ids) == 3


def test_3_put_consulta():
    consulta_id = ids[1]
    update_data = {"id_paciente": 2, "id_medico": 2, "data_consulta": "2025-09-15T15:00"}

    response = requests.put(f"{BASE_URL}/{consulta_id}", json=update_data)
    assert response.status_code == 200


def test_4_delete_consulta():
    consulta_id = ids[2]
    response = requests.delete(f"{BASE_URL}/{consulta_id}")
    assert response.status_code == 200
