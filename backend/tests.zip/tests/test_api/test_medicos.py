import requests
import uuid

BASE_URL = "http://127.0.0.1:5000/medicos"
ids = []


def test_1_post_medicos():
    medicos = [
        {"crm": str(uuid.uuid4())[:5], "nome": "Medico A", "especialidade": "Cardiologia", "cpf": str(uuid.uuid4())[:9], "telefone": "234312523", "email": "affa@mail"},
        {"crm": str(uuid.uuid4())[:5], "nome": "Medico B", "especialidade": "Ortopedia", "cpf": str(uuid.uuid4())[:9], "telefone": "234312523", "email": "affa@mail"},
        {"crm": str(uuid.uuid4())[:5], "nome": "Medico C", "especialidade": "Dermatologia", "cpf": str(uuid.uuid4())[:9], "telefone": "234312523", "email": "affa@mail"},
    ]

    for medico in medicos:
        response = requests.post(BASE_URL, json=medico)
        assert response.status_code == 201


def test_2_get_medicos():
    response = requests.get(BASE_URL)
    assert response.status_code == 200

    data = response.json()
    assert isinstance(data, list)

    for item in data[-3:]:
        ids.append(item["id"])

    assert len(ids) == 3


def test_3_put_medico():
    medico_id = ids[1]
    update_data = {"crm": str(uuid.uuid4())[:5], "nome": "Medico B Atualizado", "especialidade": "Neurologia", "cpf": str(uuid.uuid4())[:9], "telefone": "234312523", "email": "affa@mail"}

    response = requests.put(f"{BASE_URL}/{medico_id}", json=update_data)
    assert response.status_code == 200


def test_4_delete_medico():
    medico_id = ids[2]
    response = requests.delete(f"{BASE_URL}/{medico_id}")
    assert response.status_code == 200
