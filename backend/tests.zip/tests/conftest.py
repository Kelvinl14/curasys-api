# import os
# import pytest
# from pathlib import Path
# import sqlite3
#
# # Caminhos do projeto
# # BASE_DIR = Path(__file__).resolve().parent.parent
# # TESTS_DIR = Path(__file__).resolve().parent
# # TEST_DB_PATH = TESTS_DIR / "hospital_test.db"
#
# # Caminhos
# TESTS_DIR = Path(__file__).resolve().parent
# TEST_DB_PATH = TESTS_DIR / "hospital_test.db"
#
# # Aponta o banco de dados para o de testes (sobrescreve o usado em database.py)
# os.environ["TEST_DB_PATH"] = str(TEST_DB_PATH)
#
#
# # Adiciona flags customizadas ao pytest
# def pytest_addoption(parser):
#     parser.addoption(
#         "--init-db", action="store_true", default=False, help="Inicializa o banco de dados de teste"
#     )
#     parser.addoption(
#         "--reset-db", action="store_true", default=False, help="Reseta o banco de dados de teste"
#     )
#
#
# # Fixture de sessão que decide se inicializa/reset ou mantém o DB
# @pytest.fixture(scope="session", autouse=True)
# def setup_test_db(request):
#     init_flag = request.config.getoption("--init-db")
#     reset_flag = request.config.getoption("--reset-db")
#
#     if reset_flag and TEST_DB_PATH.exists():
#         TEST_DB_PATH.unlink()  # apaga o DB de teste para recriar do zero
#
#     if init_flag or reset_flag or not TEST_DB_PATH.exists():
#         from CuraSys.backend.init_db import init_db  # importa sua função real
#         init_db(str(TEST_DB_PATH))  # cria o schema no banco de teste
#
#     yield  # Aqui os testes rodam normalmente
#
#     # 🔴 se quiser manter o DB para inspeção, comente o unlink
#     # if TEST_DB_PATH.exists():
#     #     TEST_DB_PATH.unlink()
